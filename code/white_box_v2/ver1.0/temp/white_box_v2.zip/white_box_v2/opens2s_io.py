import sys
from pathlib import Path
from typing import Any

import torch

from config import cfg

try:
    from src.constants import (
        AUDIO_TOKEN_INDEX,
        DEFAULT_AUDIO_TOKEN,
        DEFAULT_AUDIO_START_TOKEN,
        DEFAULT_AUDIO_END_TOKEN,
        DEFAULT_TTS_START_TOKEN,
        IGNORE_INDEX,
    )
except Exception:
    # Fallback if OpenS2S is not on sys.path yet.
    AUDIO_TOKEN_INDEX = -200
    DEFAULT_AUDIO_TOKEN = "<|im_audio|>"
    DEFAULT_AUDIO_START_TOKEN = "<|im_audio_start|>"
    DEFAULT_AUDIO_END_TOKEN = "<|im_audio_end|>"
    DEFAULT_TTS_START_TOKEN = "<|im_tts_start|>"
    IGNORE_INDEX = -100


def _ensure_opens2s_on_path(opens2s_root: Path) -> None:
    if str(opens2s_root) not in sys.path:
        sys.path.insert(0, str(opens2s_root))


def load_opens2s(model_path: Path, device: str, opens2s_root: Path) -> tuple[Any, Any]:
    """
    Load OpenS2S model + tokenizer.
    Methodology §4.1: reuse OpenS2S input conventions.
    """
    _ensure_opens2s_on_path(opens2s_root)
    try:
        from src.modeling_omnispeech import OmniSpeechModel  # type: ignore
        from transformers import AutoTokenizer
    except Exception as exc:
        raise RuntimeError("OpenS2S imports failed. Check opens2s_root and dependencies.") from exc

    # Explicitly set CUDA device before model loading
    if device.startswith("cuda"):
        if ":" in device:
            torch.cuda.set_device(int(device.split(':')[1]))
        else:
            torch.cuda.set_device(0)

        # Clear cache before loading
        try:
            torch.cuda.empty_cache()
        except Exception:
            pass

    try:
        tokenizer = AutoTokenizer.from_pretrained(model_path, fix_mistral_regex=True)
    except TypeError:
         tokenizer = AutoTokenizer.from_pretrained(model_path)

    model = OmniSpeechModel.from_pretrained(
        model_path,
        torch_dtype=torch.bfloat16 if device.startswith("cuda") else torch.float32,
        device_map=device if device.startswith("cuda") else None
    )
    model = model.to(device)
    model.eval()
    
    # Enable gradient checkpointing to save memory
    if hasattr(model, "gradient_checkpointing_enable"):
        try:
            model.gradient_checkpointing_enable()
        except ValueError:
            # Fallback for models that don't support it directly
            if hasattr(model, "llm_model") and hasattr(model.llm_model, "gradient_checkpointing_enable"):
                 model.llm_model.gradient_checkpointing_enable()
                 print("Enabled gradient checkpointing on llm_model")
            
            if hasattr(model, "audio_encoder_model") and hasattr(model.audio_encoder_model, "gradient_checkpointing_enable"):
                 model.audio_encoder_model.gradient_checkpointing_enable()
                 print("Enabled gradient checkpointing on audio_encoder_model")

            else:
                 print("Could not enable gradient checkpointing completely")
        
    return model, tokenizer


def _build_input_ids(tokenizer, prompt: str) -> torch.LongTensor:
    # Methodology §4.1: OpenS2S chat template + audio token insertion.
    messages = [
        {
            "role": "user",
            "content": f"{DEFAULT_AUDIO_START_TOKEN}{DEFAULT_AUDIO_TOKEN}{DEFAULT_AUDIO_END_TOKEN}{prompt}",
        }
    ]
    try:
        prompt_text = tokenizer.apply_chat_template(
            messages, add_generation_prompt=True, tokenize=False, enable_thinking=False
        )
    except TypeError:
        prompt_text = tokenizer.apply_chat_template(
            messages, add_generation_prompt=True, tokenize=False
        )
    prompt_text += DEFAULT_TTS_START_TOKEN

    segments = prompt_text.split(f"{DEFAULT_AUDIO_TOKEN}")
    input_ids = []
    for idx, segment in enumerate(segments):
        if idx != 0:
            input_ids.append(AUDIO_TOKEN_INDEX)
        input_ids.extend(tokenizer.encode(segment))
    return torch.LongTensor(input_ids).unsqueeze(0)


def _torch_log_mel(waveform: torch.Tensor, sr: int) -> torch.Tensor:
    """
    Differentiable log-mel placeholder.
    Methodology §4.2: keep torch-only ops to preserve gradient.
    """
    import torchaudio

    mel_transform = torchaudio.transforms.MelSpectrogram(
        sample_rate=sr,
        n_fft=cfg.n_fft,
        hop_length=cfg.hop_length,
        win_length=cfg.win_length,
        n_mels=cfg.n_mels,
        center=True,
        power=2.0,
    ).to(waveform.device)
    
    mel = mel_transform(waveform)
    log_mel = torch.log(mel + 1e-6)
    return log_mel


def build_inputs(waveform: torch.Tensor, sr: int, prompt: str, tokenizer, device: str) -> dict:
    """
    Build inputs for OpenS2S forward.
    Methodology §4.1: (input_ids, speech_values, speech_mask) are required.
    """
    input_ids = _build_input_ids(tokenizer, prompt).to(device)
    speech_values = _torch_log_mel(waveform, sr)
    if speech_values.dim() == 2:
        speech_values = speech_values.unsqueeze(0)

    # Pad to multiple of 3000 frames (OpenS2S requirement)
    # Shape: [Batch, n_mels, Time]
    time_steps = speech_values.shape[-1]
    pad_len = (3000 - (time_steps % 3000)) % 3000
    if pad_len > 0:
        speech_values = torch.nn.functional.pad(speech_values, (0, pad_len))

    speech_values = speech_values.to(device)

    speech_mask = torch.ones(speech_values.shape[0], speech_values.shape[-1], device=device, dtype=torch.long)
    if pad_len > 0:
        speech_mask[..., -pad_len:] = 0

    # Create attention_mask for text
    attention_mask = torch.ones_like(input_ids, device=device)

    # Methodology §4.2: enforce differentiable path from waveform -> speech_values.
    if not speech_values.requires_grad:
        speech_values.requires_grad_(True)

    return {
        "input_ids": input_ids,
        "attention_mask": attention_mask,
        "speech_values": speech_values,
        "speech_mask": speech_mask,
    }


def forward_logits(model, inputs: dict) -> Any:
    outputs = model(
        input_ids=inputs["input_ids"],
        attention_mask=inputs.get("attention_mask"),
        speech_values=inputs.get("speech_values"),
        speech_mask=inputs.get("speech_mask"),
        labels=inputs.get("labels"),
        token_types=None,
        speech_units=None,
        speech_units_mask=None,
        spk_embs=None,
        return_dict=True,
    )
    return outputs


def decode_text(
    model,
    tokenizer,
    waveform: torch.Tensor,
    sr: int,
    prompt: str,
    max_new_tokens: int,
    temperature: float,
) -> str:
    # Methodology §8.1: temperature=0, greedy decode.
    inputs = build_inputs(waveform, sr, prompt, tokenizer, waveform.device)

    do_sample = temperature > 0.001
    
    from transformers import GenerationConfig
    gen_config = GenerationConfig(
        max_new_tokens=max_new_tokens,
        do_sample=do_sample,
        temperature=temperature,
        use_cache=True,
        pad_token_id=tokenizer.eos_token_id,
        eos_token_id=tokenizer.eos_token_id
    )

    generated = model.generate(
        input_ids=inputs["input_ids"],
        attention_mask=inputs.get("attention_mask"),
        speech_values=inputs.get("speech_values"),
        speech_mask=inputs.get("speech_mask"),
        spk_emb=None,
        generation_config=gen_config,
    )

    # OpenS2S model.generate() returns ONLY generated tokens, not input+generated
    # So we don't need to slice
    gen_tokens = generated
    return tokenizer.decode(gen_tokens[0], skip_special_tokens=True).strip()
